import { requireRole } from "@/lib/auth";
import { getT } from "@/lib/i18n-server";
import DashCard from "@/components/DashCard";

export default async function TeacherDashboard() {
  const profile = await requireRole(["teacher"]);
  const t = await getT();
  return (
    <div>
      <h1 className="text-2xl font-bold">{t("dash.teacher")}</h1>
      <p className="mt-1 text-slate-400">{t("common.welcome")}, {profile.full_name ?? ""}.</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <DashCard href="/dashboard/announcements" icon="📣" title={t("nav.announcements")} desc={t("card.announcements.desc")} />
        <DashCard href="/dashboard/subjects" icon="📚" title={t("card.subjects.title")} desc={t("card.subjects.desc")} />
        <DashCard href="/dashboard/profile" icon="👤" title={t("card.profile.title")} desc={t("card.profile.desc")} />
      </div>
      <p className="mt-6 text-xs text-slate-500">{t("dash.moreModules")}</p>
    </div>
  );
}
