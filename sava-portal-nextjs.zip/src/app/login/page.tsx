"use client";

import { useEffect, useRef, useState, Fragment } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { useI18n } from "@/components/I18nProvider";
import { LOCALES, type Locale } from "@/lib/i18n";
import "./login.css";

type Dept = { id: string; name: string; icon: string; a: string; b: string; mode: string };

const DEPTS: Dept[] = [
  { id: "nursing", name: "Nursing", icon: "🩺", a: "#2BE5CE", b: "#37D7F0", mode: "ecg" },
  { id: "pharmacy", name: "Pharmacy", icon: "💊", a: "#34D399", b: "#6EE7B7", mode: "pills" },
  { id: "lab", name: "Medical Laboratory", icon: "🧬", a: "#A78BFA", b: "#C4B5FD", mode: "dna" },
  { id: "dental", name: "Dental Technology", icon: "🦷", a: "#38BDF8", b: "#7DD3FC", mode: "scan" },
  { id: "aesthetic", name: "Aesthetic Clinic", icon: "✨", a: "#F472B6", b: "#F9A8D4", mode: "glow" },
  { id: "english", name: "English", icon: "📖", a: "#FBBF24", b: "#FCD34D", mode: "bars" },
  { id: "admin", name: "Hospital Administration", icon: "🏥", a: "#2E7BFF", b: "#60A5FA", mode: "network" },
  { id: "marketing", name: "Marketing", icon: "📣", a: "#FB923C", b: "#FDBA74", mode: "glow" },
  { id: "network", name: "Network Services", icon: "🌐", a: "#818CF8", b: "#A5B4FC", mode: "network" },
];

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [deptId, setDeptId] = useState("nursing");
  const [menuOpen, setMenuOpen] = useState(false);
  const { locale, setLocale, t } = useI18n();

  const heroRef = useRef<HTMLDivElement>(null);
  const sparkRef = useRef<HTMLCanvasElement>(null);
  const motifRef = useRef<HTMLCanvasElement>(null);
  const clockRef = useRef<HTMLSpanElement>(null);
  const applyRef = useRef<((d: Dept) => void) | null>(null);

  const dept = DEPTS.find((d) => d.id === deptId) || DEPTS[0];

  function selectDept(d: Dept) {
    setDeptId(d.id);
    setMenuOpen(false);
    applyRef.current?.(d);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }
    router.push("/dashboard");
    router.refresh();
  }

  // close dept menu on outside click
  useEffect(() => {
    if (!menuOpen) return;
    const close = () => setMenuOpen(false);
    document.addEventListener("click", close);
    return () => document.removeEventListener("click", close);
  }, [menuOpen]);

  // all canvas + ambient animation
  useEffect(() => {
    const hero = heroRef.current;
    const sparkCv = sparkRef.current;
    const motifCv = motifRef.current;
    if (!hero || !sparkCv || !motifCv) return;
    const sxc = sparkCv.getContext("2d");
    const mxc = motifCv.getContext("2d");
    if (!sxc || !mxc) return;
    const sx = sxc;
    const mx = mxc;
    const clockEl = clockRef.current;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const DPR = () => Math.min(window.devicePixelRatio || 1, 2);
    let raf1 = 0, raf2 = 0, rt = 0;

    // slideshow
    const slides = Array.from(hero.querySelectorAll<HTMLElement>(".slide"));
    let si = 0;
    const slideInt = window.setInterval(() => {
      if (!slides.length) return;
      slides[si].classList.remove("is-active");
      si = (si + 1) % slides.length;
      slides[si].classList.add("is-active");
    }, 5000);

    // clock
    const tick = () => {
      if (clockEl) clockEl.textContent = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
    };
    tick();
    const clockInt = window.setInterval(tick, 1000);

    // parallax + spotlight
    const bg = hero.querySelector<HTMLElement>(".hero-bg");
    const aura = hero.querySelector<HTMLElement>(".aura");
    const onMove = (e: MouseEvent) => {
      const r = hero.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      hero.style.setProperty("--mx", e.clientX - r.left + "px");
      hero.style.setProperty("--my", e.clientY - r.top + "px");
      if (bg) bg.style.transform = `translate(${x * -16}px, ${y * -12}px)`;
      if (aura) aura.style.transform = `translate(${x * 24}px, ${y * 18}px)`;
    };
    const onLeave = () => {
      if (bg) bg.style.transform = "";
      if (aura) aura.style.transform = "";
    };
    hero.addEventListener("mousemove", onMove);
    hero.addEventListener("mouseleave", onLeave);

    // sparkles
    let SCOLORS = ["#2BE5CE", "#37D7F0", "#EAF3F8", "#DDEBF7"];
    const sprites: Record<string, HTMLCanvasElement> = {};
    const buildSprites = () => {
      for (const c of SCOLORS) {
        if (sprites[c]) continue;
        const s = document.createElement("canvas");
        s.width = s.height = 32;
        const g = s.getContext("2d");
        if (!g) continue;
        const grd = g.createRadialGradient(16, 16, 0, 16, 16, 16);
        grd.addColorStop(0, c);
        grd.addColorStop(0.35, c);
        grd.addColorStop(1, "rgba(0,0,0,0)");
        g.fillStyle = grd;
        g.beginPath();
        g.arc(16, 16, 16, 0, 7);
        g.fill();
        sprites[c] = s;
      }
    };
    buildSprites();
    let SW = 0, SH = 0;
    let ps: any[] = [];
    let bursts: any[] = [];
    const srnd = (a: number, b: number) => a + Math.random() * (b - a);
    const sbuild = () => {
      const r = sparkCv.getBoundingClientRect();
      SW = r.width; SH = r.height;
      const dpr = DPR();
      sparkCv.width = SW * dpr; sparkCv.height = SH * dpr;
      sx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.round(Math.min(SW, 1100) / 16);
      ps = [];
      for (let i = 0; i < count; i++) ps.push({ x: srnd(0, SW), y: srnd(0, SH), r: srnd(0.5, 1.9), vx: srnd(-0.05, 0.05), vy: srnd(-0.22, -0.04), a: srnd(0.1, 0.85), tw: srnd(0.004, 0.016), d: Math.random() < 0.5 ? 1 : -1, c: SCOLORS[(Math.random() * SCOLORS.length) | 0] });
    };
    const sspr = (c: string, x: number, y: number, r: number, a: number) => {
      const s = sprites[c] || sprites[SCOLORS[0]];
      if (!s) return;
      const sz = r * 7;
      sx.globalAlpha = Math.max(0, a);
      sx.drawImage(s, x - sz / 2, y - sz / 2, sz, sz);
    };
    const sburst = (x: number, y: number) => {
      if (reduce) return;
      for (let i = 0; i < 16; i++) {
        const ang = (6.283 * i) / 16 + srnd(-0.25, 0.25), sp = srnd(0.7, 2.4);
        bursts.push({ x, y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, r: srnd(1, 2.8), a: 1, dec: srnd(0.012, 0.028), c: SCOLORS[(Math.random() * SCOLORS.length) | 0] });
      }
    };
    const sframe = () => {
      sx.clearRect(0, 0, SW, SH);
      for (const p of ps) {
        p.x += p.vx; p.y += p.vy; p.a += p.tw * p.d;
        if (p.a > 0.9) { p.a = 0.9; p.d = -1; }
        if (p.a < 0.07) { p.a = 0.07; p.d = 1; }
        if (p.y < -6) { p.y = SH + 6; p.x = srnd(0, SW); }
        if (p.x < -6) p.x = SW + 6;
        if (p.x > SW + 6) p.x = -6;
        sspr(p.c, p.x, p.y, p.r, p.a);
      }
      for (let i = bursts.length - 1; i >= 0; i--) {
        const b = bursts[i];
        b.x += b.vx; b.y += b.vy; b.vx *= 0.95; b.vy *= 0.95; b.vy += 0.012; b.a -= b.dec;
        if (b.a <= 0) { bursts.splice(i, 1); continue; }
        sspr(b.c, b.x, b.y, b.r, b.a);
      }
      sx.globalAlpha = 1;
      raf1 = requestAnimationFrame(sframe);
    };
    sbuild();
    if (reduce) { for (const p of ps) sspr(p.c, p.x, p.y, p.r, p.a); } else sframe();
    const onDown = (e: PointerEvent) => {
      const r = sparkCv.getBoundingClientRect();
      sburst(e.clientX - r.left, e.clientY - r.top);
    };
    hero.addEventListener("pointerdown", onDown);
    const setSparkleColors = (cols: string[]) => {
      SCOLORS = cols.slice();
      buildSprites();
      for (const p of ps) p.c = SCOLORS[(Math.random() * SCOLORS.length) | 0];
    };

    // motif (department signature animation)
    let MW = 0, MH = 0, t = 0, mode = "ecg", col = "#2BE5CE", col2 = "#37D7F0";
    let items: any[] = [];
    const mrnd = (a: number, b: number) => a + Math.random() * (b - a);
    const minit = () => {
      items = [];
      if (mode === "pills") { const n = Math.max(4, Math.round(MW / 90)); for (let i = 0; i < n; i++) items.push({ x: mrnd(0, MW), y: mrnd(0, MH), vy: mrnd(0.2, 0.5), rot: mrnd(0, 6.28), vr: mrnd(-0.02, 0.02), len: mrnd(16, 26) }); }
      else if (mode === "network") { const n = Math.max(5, Math.round(Math.min(MW, 700) / 46)); for (let i = 0; i < n; i++) items.push({ x: mrnd(0, MW), y: mrnd(0, MH), vx: mrnd(-0.3, 0.3), vy: mrnd(-0.3, 0.3) }); }
      else if (mode === "bars") { const n = Math.max(8, Math.round(MW / 16)); for (let i = 0; i < n; i++) items.push({ p: mrnd(0, 6.28), s: mrnd(0.04, 0.09) }); }
      else if (mode === "glow" || mode === "scan") { const n = Math.max(6, Math.round(MW / 26)); for (let i = 0; i < n; i++) items.push({ x: mrnd(0, MW), y: mrnd(0, MH), a: mrnd(0.1, 0.6), tw: mrnd(0.01, 0.03), d: Math.random() < 0.5 ? 1 : -1 }); }
    };
    const msize = () => {
      const r = motifCv.getBoundingClientRect();
      MW = r.width; MH = Math.max(r.height, 1);
      const dpr = DPR();
      motifCv.width = MW * dpr; motifCv.height = MH * dpr;
      mx.setTransform(dpr, 0, 0, dpr, 0, 0);
      minit();
      if (reduce) mframe();
    };
    const mdot = (x: number, y: number, r: number, c: string, a: number) => {
      mx.globalAlpha = a; mx.fillStyle = c; mx.beginPath(); mx.arc(x, y, r, 0, 6.2832); mx.fill();
    };
    const mframe = () => {
      t++; mx.clearRect(0, 0, MW, MH); const mid = MH / 2; mx.lineCap = "round"; mx.lineJoin = "round";
      if (mode === "ecg") {
        const TW = 300, amp = MH * 0.42;
        const tile = [[0, 0], [70, 0], [84, -0.18], [96, 0.12], [108, 0], [150, 0], [160, -1], [172, 0.9], [182, 0], [210, 0], [224, -0.27], [240, 0.27], [256, 0], [300, 0]];
        const off = (t * 1.7) % TW; mx.save(); mx.shadowBlur = 8; mx.shadowColor = col; mx.strokeStyle = col; mx.lineWidth = 2.2; mx.beginPath(); let st = false;
        for (let bx = -off; bx < MW + TW; bx += TW) { for (const p of tile) { const X = bx + p[0], Y = mid + p[1] * amp; if (!st) { mx.moveTo(X, Y); st = true; } else mx.lineTo(X, Y); } }
        mx.stroke(); mx.restore(); mdot(MW * 0.9, mid, 3, col, 1);
      } else if (mode === "pills") {
        mx.save(); mx.shadowBlur = 8; mx.shadowColor = col;
        for (const it of items) {
          it.y -= it.vy; it.rot += it.vr; if (it.y < -22) { it.y = MH + 22; it.x = mrnd(0, MW); }
          mx.save(); mx.translate(it.x, it.y); mx.rotate(it.rot); const w = it.len, h = it.len * 0.46, r = h / 2;
          const g = mx.createLinearGradient(-w / 2, 0, w / 2, 0); g.addColorStop(0, col); g.addColorStop(0.5, col); g.addColorStop(0.5, col2); g.addColorStop(1, col2);
          mx.globalAlpha = 0.92; mx.fillStyle = g; mx.beginPath(); (mx as any).roundRect(-w / 2, -h / 2, w, h, r); mx.fill();
          mx.globalAlpha = 0.5; mx.strokeStyle = "rgba(255,255,255,.65)"; mx.lineWidth = 1; mx.beginPath(); mx.moveTo(0, -h / 2 + 1.5); mx.lineTo(0, h / 2 - 1.5); mx.stroke();
          mx.restore();
        }
        mx.restore(); mx.globalAlpha = 1;
      } else if (mode === "dna") {
        mx.save(); const amp = MH * 0.34, step = 16;
        for (let x = 0; x <= MW; x += step) {
          const ph = x * 0.045 - t * 0.04; const y1 = mid + Math.sin(ph) * amp, y2 = mid + Math.sin(ph + Math.PI) * amp; const front = Math.cos(ph) > 0;
          if ((((x / step) | 0) % 2) === 0) { mx.globalAlpha = 0.22; mx.strokeStyle = col2; mx.lineWidth = 1.4; mx.beginPath(); mx.moveTo(x, y1); mx.lineTo(x, y2); mx.stroke(); }
          mx.shadowBlur = 6; mx.shadowColor = col; mdot(x, front ? y1 : y2, 2.6, col, 0.95); mx.shadowColor = col2; mdot(x, front ? y2 : y1, 2.4, col2, 0.6);
        }
        mx.restore(); mx.globalAlpha = 1;
      } else if (mode === "scan") {
        for (const it of items) { it.a += it.tw * it.d; if (it.a > 0.6) { it.a = 0.6; it.d = -1; } if (it.a < 0.08) { it.a = 0.08; it.d = 1; } mdot(it.x, it.y, 1.4, col2, it.a); }
        const sxp = ((t * 2.2) % (MW + 120)) - 60; const g = mx.createLinearGradient(sxp - 30, 0, sxp + 30, 0); g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(0.5, col); g.addColorStop(1, "rgba(0,0,0,0)");
        mx.save(); mx.globalAlpha = 0.85; mx.shadowBlur = 12; mx.shadowColor = col; mx.fillStyle = g; mx.fillRect(sxp - 30, 0, 60, MH); mx.restore(); mdot(sxp, mid, 2.4, col, 1); mx.globalAlpha = 1;
      } else if (mode === "glow") {
        const maxR = Math.min(MW, MH * 2.6) / 2; mx.save(); mx.lineWidth = 2; mx.shadowBlur = 10; mx.shadowColor = col;
        for (let k = 0; k < 3; k++) { const r = (t * 1.3 + k * 46) % maxR; const a = Math.max(0, 0.5 * (1 - r / maxR)); mx.globalAlpha = a; mx.strokeStyle = col; mx.beginPath(); mx.arc(MW / 2, mid, r, 0, 6.2832); mx.stroke(); }
        mx.restore();
        for (const it of items) { it.a += it.tw * it.d; if (it.a > 0.7) { it.a = 0.7; it.d = -1; } if (it.a < 0.06) { it.a = 0.06; it.d = 1; } mdot(it.x, it.y, 1.5, col2, it.a); }
        mx.globalAlpha = 1;
      } else if (mode === "bars") {
        const n = items.length, gap = 4, bw = Math.max(2, MW / n - gap); mx.save(); mx.shadowBlur = 8; mx.shadowColor = col;
        for (let i = 0; i < n; i++) { const it = items[i]; const h = (0.22 + 0.7 * (0.5 + 0.5 * Math.sin(t * it.s + it.p))) * MH; const x = i * (bw + gap);
          const g = mx.createLinearGradient(0, mid + h / 2, 0, mid - h / 2); g.addColorStop(0, col2); g.addColorStop(1, col); mx.fillStyle = g; mx.globalAlpha = 0.92;
          mx.beginPath(); (mx as any).roundRect(x, mid - h / 2, bw, h, Math.min(bw / 2, 3)); mx.fill(); }
        mx.restore(); mx.globalAlpha = 1;
      } else if (mode === "network") {
        for (const it of items) { it.x += it.vx; it.y += it.vy; if (it.x < 0 || it.x > MW) it.vx *= -1; if (it.y < 0 || it.y > MH) it.vy *= -1; }
        mx.lineWidth = 1;
        for (let i = 0; i < items.length; i++) { for (let j = i + 1; j < items.length; j++) { const a = items[i], b = items[j], dx = a.x - b.x, dy = a.y - b.y, d = Math.hypot(dx, dy); if (d < 92) { mx.globalAlpha = 0.5 * (1 - d / 92); mx.strokeStyle = col; mx.beginPath(); mx.moveTo(a.x, a.y); mx.lineTo(b.x, b.y); mx.stroke(); } } }
        mx.save(); mx.shadowBlur = 8; mx.shadowColor = col; for (const it of items) mdot(it.x, it.y, 2.4, col2, 0.95); mx.restore(); mx.globalAlpha = 1;
      }
      if (!reduce) raf2 = requestAnimationFrame(mframe);
    };
    const setMotif = (m: string, c: string, c2: string) => { mode = m; col = c; col2 = c2; minit(); if (reduce) mframe(); };
    msize();
    if (!reduce) mframe();

    const onResize = () => { window.clearTimeout(rt); rt = window.setTimeout(() => { sbuild(); msize(); }, 150); };
    window.addEventListener("resize", onResize);

    const applyDept = (d: Dept) => { setMotif(d.mode, d.a, d.b); setSparkleColors([d.a, d.b, "#EAF3F8", "#DDEBF7"]); };
    applyRef.current = applyDept;
    const init = DEPTS.find((x) => x.id === "nursing");
    if (init) applyDept(init);

    return () => {
      window.clearInterval(slideInt);
      window.clearInterval(clockInt);
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(raf2);
      window.clearTimeout(rt);
      window.removeEventListener("resize", onResize);
      hero.removeEventListener("mousemove", onMove);
      hero.removeEventListener("mouseleave", onLeave);
      hero.removeEventListener("pointerdown", onDown);
      applyRef.current = null;
    };
  }, []);

  const rootStyle = { "--accent": dept.a, "--accent-2": dept.b } as Record<string, string> as React.CSSProperties;

  return (
    <main id="savaLogin" style={rootStyle}>
      <section className="hero" ref={heroRef}>
        <div className="hero-bg">
          <div className="slide is-active" style={{ backgroundImage: "url('/campus-1.jpg')" }} />
          <div className="slide" style={{ backgroundImage: "url('/campus-3.jpg')" }} />
          <div className="slide" style={{ backgroundImage: "url('/campus-4.jpg')" }} />
        </div>
        <div className="hero-veil" />
        <div className="aura"><span className="orb a" /><span className="orb b" /><span className="orb c" /></div>
        <canvas className="sparkles" ref={sparkRef} />
        <div className="grain" />
        <div className="spot" />
        <div className="vignette" />

        <div className="topbar">
          <div className="brandbar">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img className="brandmark" src="/sava-logo.jpg" alt="SAVA logo" />
            <div className="brandtext"><strong>SAVA</strong><span>Technical Institute</span></div>
          </div>
          <div className="hud">
            <span className="status"><span className="dot" />{t("login.portalOnline")}</span>
            <span className="sep">/</span>
            <span className="clock" ref={clockRef}>--:--:--</span>
          </div>
        </div>

        <div className="hero-body">
          <p className="eyebrow">{dept.name.toUpperCase()} · {t("login.studentPortal")}</p>
          <h1 className="display">{t("login.heroLine1")}<br /><em>{t("login.heroLine2")}</em></h1>
          <p className="lede">{t("login.heroLede")}</p>
          <canvas className="monitor" ref={motifRef} />
          <div className="depts">
            {DEPTS.map((d, idx) => (
              <Fragment key={d.id}>
                {idx > 0 && <i>·</i>}
                {d.id === deptId ? <b>{d.name}</b> : <span>{d.name}</span>}
              </Fragment>
            ))}
          </div>
        </div>
      </section>

      <section className="auth">
        <div className="auth-card">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img className="auth-logo" src="/sava-logo.jpg" alt="" />
          <h2 className="auth-title">{t("login.welcomeTitle")}</h2>
          <p className="auth-sub">{t("login.signInSub")}</p>
          <form onSubmit={onSubmit}>
            <div className="field dept-field">
              <span className="flabel">{t("profile.department")}</span>
              <button type="button" className="dept-btn" aria-haspopup="listbox" aria-expanded={menuOpen} onClick={(e) => { e.stopPropagation(); setMenuOpen((o) => !o); }}>
                <span className="dept-cur"><span className="di">{dept.icon}</span><span>{dept.name}</span></span>
                <span className="chev">▾</span>
              </button>
              {menuOpen && (
                <div className="dept-menu" role="listbox" onClick={(e) => e.stopPropagation()}>
                  {DEPTS.map((d) => (
                    <button key={d.id} type="button" role="option" aria-selected={d.id === deptId} className={"dept-opt" + (d.id === deptId ? " sel" : "")} onClick={() => selectDept(d)}>
                      <span className="di">{d.icon}</span><span>{d.name}</span><span className="ck">✓</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <label className="field"><span className="flabel">{t("login.email")}</span>
              <input type="email" required placeholder="you@sava.edu" value={email} onChange={(e) => setEmail(e.target.value)} />
            </label>
            <label className="field"><span className="flabel">{t("login.password")}</span>
              <input type="password" required placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} />
            </label>
            {error && <p className="err">{error}</p>}
            <button className="btn" type="submit" disabled={loading}>{loading ? t("login.signingIn") : t("login.signIn")} <span className="btn-arrow">→</span></button>
          </form>
          <p className="auth-alt">{t("login.newHere")} <Link href="/signup">{t("login.createAccount")}</Link></p>
          <div className="auth-foot">
            <div className="langs">
              {LOCALES.map((l) => (
                <button key={l} type="button" className={"lang" + (locale === l ? " on" : "")} onClick={() => setLocale(l as Locale)}>{l.toUpperCase()}</button>
              ))}
            </div>
          </div>
        </div>
        <p className="credit">{t("credit.designedBy")} <b>Aland Hiwa</b></p>
      </section>
    </main>
  );
}
