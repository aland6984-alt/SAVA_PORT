import type { Metadata } from "next";
import "./globals.css";
import { getLocale } from "@/lib/i18n-server";
import { isRTL } from "@/lib/i18n";
import I18nProvider from "@/components/I18nProvider";

export const metadata: Metadata = {
  title: "SAVA Technical Institute",
  description: "Institute management portal",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const locale = await getLocale();
  return (
    <html lang={locale} dir={isRTL(locale) ? "rtl" : "ltr"}>
      <body className="min-h-screen bg-slate-950 text-slate-100 antialiased">
        <I18nProvider locale={locale}>{children}</I18nProvider>
      </body>
    </html>
  );
}
