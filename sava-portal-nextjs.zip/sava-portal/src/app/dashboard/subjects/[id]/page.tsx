import { notFound } from "next/navigation";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import type { Grade, Subject } from "@/lib/grades";
import type { Profile } from "@/lib/types";
import Gradebook from "./Gradebook";

export const dynamic = "force-dynamic";

export default async function SubjectGradebookPage({
  params,
}: {
  params: { id: string };
}) {
  await requireRole(["admin", "super_admin", "teacher"]);
  const supabase = await createClient();

  const { data: subject } = await supabase
    .from("subjects")
    .select("*")
    .eq("id", params.id)
    .single();
  if (!subject) notFound();
  const subj = subject as Subject;

  const { data: studentsData } = await supabase
    .from("profiles")
    .select("*")
    .eq("role", "student")
    .eq("department", subj.department)
    .eq("year", subj.year)
    .order("full_name");

  const { data: gradesData } = await supabase
    .from("grades")
    .select("*")
    .eq("subject_id", subj.id);

  return (
    <Gradebook
      subject={subj}
      students={(studentsData as Profile[]) ?? []}
      grades={(gradesData as Grade[]) ?? []}
    />
  );
}
