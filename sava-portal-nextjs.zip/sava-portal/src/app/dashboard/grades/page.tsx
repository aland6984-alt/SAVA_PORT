import { redirect } from "next/navigation";
import { getSessionProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import {
  EXAM_PARTS,
  EXAM_PART_LABEL,
  computeFinal,
  computeGpa,
  isPass,
  letterGrade,
  normalizeWeights,
  statusColor,
  type Grade,
  type Subject,
} from "@/lib/grades";

export const dynamic = "force-dynamic";

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-center">
      <div className="text-2xl font-bold">{value}</div>
      <div className="mt-1 text-xs text-slate-400">{label}</div>
    </div>
  );
}

export default async function GradesPage() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login");

  if (profile.role !== "student") {
    return (
      <div>
        <h1 className="text-xl font-bold">Grades</h1>
        <p className="mt-2 text-sm text-slate-400">
          Grades are shown to students here. Use the <b>Subjects</b> page to enter grades.
        </p>
      </div>
    );
  }

  const supabase = await createClient();
  let subjects: Subject[] = [];
  if (profile.department && profile.year) {
    const { data } = await supabase
      .from("subjects")
      .select("*")
      .eq("department", profile.department)
      .eq("year", profile.year)
      .order("name");
    subjects = (data as Subject[]) ?? [];
  }
  const { data: gradeData } = await supabase
    .from("grades")
    .select("*")
    .eq("student_id", profile.id);
  const grades = (gradeData as Grade[]) ?? [];

  const rows = subjects.map((s) => {
    const g = grades.find((x) => x.subject_id === s.id);
    const final = g ? computeFinal(g, normalizeWeights(s.exam_weights)) : null;
    return { subject: s, grade: g, final };
  });
  const gpa = computeGpa(rows.map((r) => r.final));

  return (
    <div>
      <h1 className="text-xl font-bold">My grades</h1>
      <p className="mb-5 mt-1 text-sm text-slate-400">
        {profile.department
          ? `${profile.department} · Year ${profile.year}`
          : "No class assigned yet — ask an admin to set your department and year."}
      </p>

      <div className="mb-5 grid grid-cols-3 gap-3">
        <Stat label="GPA" value={gpa.total ? gpa.gpa.toFixed(2) : "—"} />
        <Stat label="Average" value={gpa.total ? `${gpa.avg}%` : "—"} />
        <Stat label="Passed" value={gpa.total ? `${gpa.passed}/${gpa.total}` : "—"} />
      </div>

      {rows.length === 0 ? (
        <p className="text-sm text-slate-500">No subjects yet. Your teachers will add them.</p>
      ) : (
        <div className="space-y-3">
          {rows.map(({ subject, grade, final }) => (
            <div key={subject.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="flex items-center justify-between gap-3">
                <h3 className="font-semibold">{subject.name}</h3>
                {final !== null ? (
                  <span className={`text-sm font-bold ${statusColor(final)}`}>
                    {final}% · {letterGrade(final)} · {isPass(final) ? "Pass" : "Fail"}
                  </span>
                ) : (
                  <span className="text-xs text-slate-500">Not graded yet</span>
                )}
              </div>
              <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-400">
                {EXAM_PARTS.map((p) => {
                  const v = grade ? grade[p] : null;
                  return (
                    <span key={p}>
                      {EXAM_PART_LABEL[p]}:{" "}
                      <b className="text-slate-200">{v !== null && v !== undefined ? v : "—"}</b>
                      <span className="text-slate-600"> ({subject.exam_weights?.[p] ?? 0}%)</span>
                    </span>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
