import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionProfile } from "@/lib/auth";
import SignOutButton from "@/components/SignOutButton";
import DashboardNav from "@/components/DashboardNav";
import { roleLabel } from "@/lib/types";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login");

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-white/10 bg-slate-950/70 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-5 py-3">
          <Link href="/dashboard" className="flex items-center gap-2 text-lg font-bold tracking-wide">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/sava-logo.jpg" alt="SAVA" className="h-8 w-8 rounded-lg ring-1 ring-white/15" />
            SAVA
          </Link>
          <div className="flex items-center gap-3 text-sm">
            <span className="hidden text-slate-400 sm:inline">
              {profile.full_name ?? "—"} ·{" "}
              <span className="text-violet-300">{roleLabel[profile.role]}</span>
            </span>
            <SignOutButton />
          </div>
        </div>
        <div className="mx-auto max-w-5xl px-5 pb-2">
          <DashboardNav role={profile.role} />
        </div>
      </header>
      <main className="mx-auto max-w-5xl p-5">{children}</main>
    </div>
  );
}
