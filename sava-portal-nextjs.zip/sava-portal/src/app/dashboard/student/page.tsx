import { requireRole } from "@/lib/auth";
import DashCard from "@/components/DashCard";

export default async function StudentDashboard() {
  const profile = await requireRole(["student"]);
  return (
    <div>
      <h1 className="text-2xl font-bold">Student Dashboard</h1>
      <p className="mt-1 text-slate-400">Welcome, {profile.full_name ?? "there"}.</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <DashCard href="/dashboard/announcements" icon="📣" title="Announcements" desc="News and notices from the institute." />
        <DashCard href="/dashboard/grades" icon="📚" title="My grades" desc="See your grades and GPA." />
        <DashCard href="/dashboard/profile" icon="👤" title="My profile" desc="Update your personal details." />
      </div>
      <p className="mt-6 text-xs text-slate-500">More modules (attendance, payments, messaging) are being added step by step.</p>
    </div>
  );
}
