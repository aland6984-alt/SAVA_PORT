import { redirect } from "next/navigation";
import { getSessionProfile } from "@/lib/auth";
import ProfileForm from "./ProfileForm";

export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login");

  return (
    <div>
      <h1 className="text-xl font-bold">My profile</h1>
      <p className="mb-5 mt-1 text-sm text-slate-400">Update your personal details.</p>
      <ProfileForm profile={profile} />
    </div>
  );
}
