import { redirect } from "next/navigation";
import { getSessionProfile } from "@/lib/auth";
import { roleHome } from "@/lib/types";

export default async function DashboardIndex() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login");
  redirect(roleHome[profile.role]);
}
